$filePath = "E:\CyberCheck\Memes\Phishing.webp"

# Check if the file exists before attempting to open it
if (Test-Path $filePath -PathType Leaf) {
    Start-Process $filePath
} else {
    Write-Host "File not found: $filePath"
}
